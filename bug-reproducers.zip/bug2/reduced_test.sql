CREATE VIRTUAL TABLE rtree_keyxe USING rtree(id, minX, maxX, minY, maxY);
INSERT INTO rtree_keyxe DEFAULT VALUES;
UPDATE rtree_keyxe SET minY = -59207.72100589708 WHERE rtree_keyxe.maxX IS NOT NULL;
SELECT * FROM rtree_keyxe AS a INNER JOIN rtree_keyxe AS b ON a.id = b.id;
