# Bug Description

## Expected Results
In SQLite 3.26.0, R-Tree virtual tables do not correctly handle `IS NOT NULL` constraints. By creating the R-Tree virtual table and inserting `DEFAULT VALUES`, the table should have `NULL` values.
```sql
CREATE VIRTUAL TABLE rtree_keyxe USING rtree(id, minX, maxX, minY, maxY);
INSERT INTO rtree_keyxe DEFAULT VALUES;
```

Therefore, in the update, the expression `rtree_keyxe.maxX IS NOT NULL` should be true.
```sql
UPDATE rtree_keyxe SET minY = -59207.72100589708 WHERE rtree_keyxe.maxX IS NOT NULL;
```

After a select query:
```sql
SELECT * FROM rtree_keyxe AS a INNER JOIN rtree_keyxe AS b ON a.id = b.id;
```

In SQLite 3.39.4, it returns:
```
1|0.0|0.0|-59207.72265625|0.0|1|0.0|0.0|-59207.72265625|0.0
```
which correctly updates the values.

## Actual Results
In SQLite 3.26.0, the select query would return:
```
1|0.0|0.0|0.0|0.0|1|0.0|0.0|0.0|0.0
```
This is because SQLite 3.26.0 does not correctly handle `IS NOT NULL` constraints. The update with the `IS NOT NULL` constraint will throw an `Error: SQL logic error` and the corresponding values does not get updated.

