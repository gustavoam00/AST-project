# Bug Description

The observed returned values between SQLite versions 3.26.0 and 3.39.4 when using `GROUP BY` without aggregate functions on a query that includes `SELECT *` are different. The query produces different rows as output, depending on the SQLite version.

## Results

SQLite version 3.39.4 returns:
|1.0|0|||11960.1801526769|

SQLite version 3.26.0 returns:
||1|||3802.84948380511|



