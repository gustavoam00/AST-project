CREATE TABLE tbl_wqiwo (icol_dhwup INTEGER, rcol_eitnk REAL DEFAULT 55001.080638557934, tcol_yqthy TEXT, rcol_bjzii REAL, icol_jcscw INTEGER, tcol_wskpp);
INSERT INTO tbl_wqiwo (rcol_eitnk, tcol_wskpp, tcol_yqthy) VALUES (1.0, 11960.180152676927, CAST('v_citjr' GLOB 'rAag' AS TEXT)), (CAST(UNLIKELY(- (NULL)) / NULLIF(0,0) AS REAL), 3802.849483805112, 1);
ALTER TABLE tbl_wqiwo ADD COLUMN icol_ovpnc INTEGER;
WITH with_vysww AS (SELECT * FROM tbl_wqiwo ORDER BY tbl_wqiwo.tcol_wskpp), with_kepqw AS (SELECT * FROM with_vysww GROUP BY with_vysww.icol_ovpnc ORDER BY with_vysww.rcol_bjzii) SELECT * FROM with_kepqw;
