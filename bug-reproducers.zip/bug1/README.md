# Bug Description

## Expected Results

According to SQLite, comparison with `NULL` using operators, such as `>=`, `=`, `<`,  should result in `NULL`, which should be false. Therefore, the query:

```sql
SELECT * FROM rtree_dihcz WHERE (rtree_dihcz.maxX >= NULL OR ...);
```

should return no rows. In SQLite version 3.39.4, the query returns no rows.

## Actual Results

However, SQLite version 3.26.0 returns:
```
1|0.0|0.0|0.0|0.0
```



