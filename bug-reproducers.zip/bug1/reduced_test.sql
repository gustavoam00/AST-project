CREATE VIRTUAL TABLE rtree_dihcz USING rtree(id, minX, maxX, minY, maxY);
INSERT INTO rtree_dihcz DEFAULT VALUES;
SELECT * FROM rtree_dihcz WHERE rtree_dihcz.maxX >= NULL;
