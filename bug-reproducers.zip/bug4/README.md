# Bug Description

In SQLite 3.26.0, inserting a row into a table with columns with ```NOT NULL DEFAULT NULL``` constraints using ```REPLACING INTO ... DEFAULT VALUES``` does not raise an error, even though the constraints are violated. This results in a row with ```NULL``` values in ```NOT NULL``` columns.

## Expected Results

SQLite version 3.39.4 returns an error message:
```Error: stepping, NOT NULL constraint failed```

Therefore, no rows are inserted. A select query on the table afterwards would return no results

## Actual Results

While in SQLite 3.26.0, inserting succeeeds. After a select query on the table, it would return a row with NULL values:
```
||
```


