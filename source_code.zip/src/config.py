QUERY_TEST_FOLDER = "log/"
SQLITE_VERSIONS = ["sqlite3-3.26.0", "sqlite3-3.39.4"]
DB1 = "./db/test1.db"
DB2 = "./db/test2.db"
BUGS_FOLDER = QUERY_TEST_FOLDER + "test2/" #"bugs/"
INFO_OUTPUT = QUERY_TEST_FOLDER + "info/"
TEMP_OUTPUT = QUERY_TEST_FOLDER + "temp/"