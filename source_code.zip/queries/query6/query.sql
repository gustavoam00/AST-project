CREATE TABLE t0 ( c1 , c2 , c5 ) ;
SELECT subq1.c13 , subq1.c13 , subq1.c13 FROM ( SELECT FALSE c13 FROM ( SELECT TRUE , t1.c1 , t1.c2 c9 , t1.c2 , t1.c5 c11 , t1.c1 FROM t0 t1 ORDER BY c9 , c11 COLLATE NOCASE ) ORDER BY c13 , c13 , c13 , c13 ) subq1 WHERE subq1.c13 = CASE subq1.c13 WHEN subq1.c13 = subq1.c13 THEN subq1.c13 ELSE subq1.c13 END ;
