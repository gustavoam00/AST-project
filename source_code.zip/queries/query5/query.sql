CREATE TABLE biq ( ype , ucn , ynu ) ;
REPLACE INTO biq ( ype , ucn , ynu ) VALUES ( CURRENT_TIMESTAMP , 1 , 1 ) ;
SELECT ucn FROM biq WHERE biq.ype / 709620288 ;
