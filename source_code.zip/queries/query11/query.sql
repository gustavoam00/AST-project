CREATE TABLE V ( l , q ) ;
SELECT * FROM ( VALUES ( NULL , false ) , ( NULL , NULL ) ) WHERE ( false <> true <> NOT true ) ;
SELECT * FROM V ;
