CREATE TABLE t_DX44 ( c_LGUf , c_Hlmf3w , c_ewZ , c_EwP , c_YBA7sBV CHECK ( c_YBA7sBV > 0 ) ) ;
INSERT INTO t_DX44 ( c_ewZ , c_EwP ) VALUES ( 'MQ_2' , 'qrZM84MTMHUkkov_3' ) , ( '7131k8CH2I7rflmaZmFh_102' , '1sGjUivjzF_103' ) , ( '6u2sAbJVjXHWP_202' , 'YpYYmjS_203' ) ;
SELECT 1 FROM t_DX44 WHERE t_DX44.c_EwP / t_DX44.c_ewZ ;
